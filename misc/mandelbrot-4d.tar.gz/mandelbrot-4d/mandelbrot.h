#define X_DIM 1920
#define Y_DIM 1080

#define oversample 1
#define escape 65535

#define n_params 20
#define params_scale 0
#define params_maxsteps 1
#define params_c_r 2
#define params_c_i 3
#define params_z0_r 4
#define params_z0_i 5
#define params_x_c_r 6
#define params_x_c_i 7
#define params_x_z0_r 8
#define params_x_z0_i 9
#define params_y_c_r 10
#define params_y_c_i 11
#define params_y_z0_r 12
#define params_y_z0_i 13
#define params_z_c_r 14
#define params_z_c_i 15
#define params_z_z0_r 16
#define params_z_z0_i 17
#define params_phi 18
#define params_phi_i 19

typedef struct complex_double
{
	double r, i;
} complex_double;

