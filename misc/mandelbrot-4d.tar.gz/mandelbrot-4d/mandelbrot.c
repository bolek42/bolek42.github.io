#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <CL/cl.h>

#define __USE_GNU
#include <math.h>

#include "mandelbrot.h"

#define KEY_ESC 0x1b
#define KEY_LEFT 0x64
#define KEY_UP 0x65
#define KEY_RIGHT 0x66
#define KEY_DOWN 0x67

double params[n_params] = {
    0.5, 30,
    0.0, 0.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0,
    1.0, 0.0, 1.0, 0.0,
    0.0, 0.0
};
const static int X = X_DIM;
const static int Y = Y_DIM;
double params_key[n_params];

double colormap(double x, double i, double n);
void normalize(double *img, int X, int Y);
void dump_ppm(char *fname, char *rgb, int X, int Y);
void redraw();
double *render();
void update_axis();

//Maps x in [0,1] to color
inline double colormap(double x, double color_id, double n_colors)
{
	if (x < color_id/n_colors || x > (color_id+2)/n_colors)
		return 0;

	return sin((x - (color_id/n_colors)) * n_colors * M_PIl * 0.5);
}

//normalizes img to [0,1]
void normalize(double *img, int X, int Y)
{
	int x, y;
	double min, max, p;

	min = -99999999999;
	min = +99999999999;

	#pragma omp parallel for private(x, p) reduction(max: max) reduction(min: min)
	for (y = 0; y < Y; y++)
		for (x = 0; x < X; x++)
		{
			p = img[y * X + x];
            if (p == p && !isinf(p)) {
                if (min > p) min = p;
                if (max < p) max = p;
            }
		}

	#pragma omp parallel for private(x, p)
	for (y = 0; y < Y; y++)
		for (x = 0; x < X; x++)
		{
			p = img[y * X + x];
			p = (p - min) / (max - min); //normalize to [0..1]
			img[y * X + x] = (p == p && !isinf(p)) ? p : 0;
		}

	return;
}

void dump_ppm(char *fname, char *rgb, int X, int Y)
{

	FILE *f;
	int x, y;
	f = fopen(fname, "w");
	fprintf(f, "P6\n");
	fprintf(f, "%d %d\n", X, Y);
	fprintf(f, "255\n");
	
	fwrite(rgb, sizeof(char), X * Y * 3, f);
	fclose(f);
}

void plot(double *img, char *fname)
{
	printf("\x1b[2J");		//clear console
	printf("\x1b[0;0H");	//reset cursor
	printf("scale:%f\n", params[params_scale]);
	printf("max steps:%f\n", params[params_maxsteps]);
	printf("c.r:%f\n", params[params_c_r]);
	printf("c.i:%f\n", params[params_c_i]);
	printf("z0.r:%f\n", params[params_z0_r]);
	printf("z0.i:%f\n", params[params_z0_i]);
	printf("cx.r:%f\n", params[params_x_c_r]);
	printf("cx.i:%f\n", params[params_x_c_i]);
	printf("z0x.r:%f\n", params[params_x_z0_r]);
	printf("z0x.i:%f\n", params[params_x_z0_i]);
	printf("cy.r:%f\n", params[params_y_c_r]);
	printf("cy.i:%f\n", params[params_y_c_i]);
	printf("z0y.r:%f\n", params[params_y_z0_r]);
	printf("z0y.i:%f\n", params[params_y_z0_i]);
	printf("phi.r:%f\n", params[params_phi]);
	printf("phi.i:%f\n", params[params_phi_i]);

	int x, y;
	unsigned char *rgb = calloc(X * Y * 3, sizeof(char));

	printf("opengl\n");
	//opengl stuff
	normalize(img, X, Y);

	#pragma omp parallel for private(x)
	for (y = 0; y < Y; y++)
		for (x = 0; x < X; x++)
		{
			rgb[(y * X + x) * 3 + 0] = colormap(img[y * X + x], 2, 3) * 255;
			rgb[(y * X + x) * 3 + 1] = colormap(img[y * X + x], 1, 3) * 255;
			rgb[(y * X + x) * 3 + 2] = colormap(img[y * X + x], 0, 3) * 255;
		}

    if (fname) dump_ppm(fname, rgb, X, Y);

	glDrawPixels(X, Y, GL_RGB, GL_UNSIGNED_BYTE, rgb);
	glutSwapBuffers();
	printf("/opengl\n");

	free(rgb);

	return;
}


void animate(int dump)
{
	int t, i;
	static int t_0 = 0;
	int n_t = 256;
	char *file = malloc(1024);
	double *img = NULL;

	//trace init
	double m[n_params];

	for (i = 0; i < n_params; i++)
	{
		m[i] = (params[i] - params_key[i]);
		params[i] = params_key[i];
	}


	for (t = 0; t < n_t; t++)
	{
		//position update
		for (i = 0; i < n_params; i++)
        {
			params[i] = params_key[i] + m[i] * sin(t * M_PI / 2 / n_t);
        }

        update_axis();
        img = render();
		if (dump)
		{
			//dump
			sprintf(file, "/tmp/out/ppm-%06d.ppm", t_0 + t);
	        plot(img, file);
		}
		else
			plot(img, NULL);

        free(img);
		printf("t: %d/%d\n", t, n_t);
	}

	for (i = 0; i < n_params; i++)
		params_key[i] = params[i];

	t_0 += n_t;

	free(file);
}


void update_axis()
{
    double phi = M_PIl * 0.5 * params[params_phi];
    double phi_i = params[params_phi_i];
    params[params_x_c_r] = cos(phi);
    params[params_x_z0_r] = sin(phi);
    params[params_y_c_i] = cos(phi);
    params[params_y_z0_i] = sin(phi);
}

//keybindings
void key_handler(unsigned char c, int x, int y)
{
	int i;
    double *img;

	switch (c)
	{
        //Misc
		case KEY_ESC:
			exit(0);
			break;

		case ';': //screenshot
            img = render();
            plot(img, "/tmp/screen.ppm");
            free(img);
			break;

		case '.': //render from keyframe to current pos.
			animate(0);
			break;

		case ',': //render and write images to Disk
			animate(1);
			break;

		case 'k': //set keyframe
			for (i = 0; i < n_params; i++)
				params_key[i] = params[i];
			break;
		case '0': //reset position to keyframe
			for (i = 0; i < n_params; i++)
				params[i] = params_key[i];
			break;

		//Pos
		case '1':
			params[params_c_r] += 0.2 / params[params_scale];
			break;
		case 'q':
			params[params_c_r] -= 0.2 / params[params_scale];
			break;
		case '2':
			params[params_c_i] -= 0.2 / params[params_scale];
			break;
		case 'w':
			params[params_c_i] += 0.2 / params[params_scale];
			break;
		case '3':
			params[params_z0_r] += 0.2 / params[params_scale];
			break;
		case 'e':
			params[params_z0_r] -= 0.2 / params[params_scale];
			break;
		case '4':
			params[params_z0_i] -= 0.2 / params[params_scale];
			break;
		case 'r':
			params[params_z0_i] += 0.2 / params[params_scale];
			break;

		//Rot
		case '5':
            params[params_phi] += 0.1;
			break;
		case 't':
            params[params_phi] -= 0.1;
			break;
		case '6':
            params[params_phi_i] += 0.1;
			break;
		case 'z':
            params[params_phi_i] -= 0.1;
			break;
		case '7':
			params[params_maxsteps] *= 1.3;
			break;
		case 'u':
			params[params_maxsteps] /= 1.3;
			break;
		case '+':
			params[params_scale] *= 1.5;
			break;
		case '-':
			params[params_scale] /= 1.5;
			break;

		default:
			break;
	}

    update_axis();
	redraw();
}

void special_key_handler(int c, int x, int y)
{
	switch (c)
	{
		case KEY_LEFT:
			printf("left\n");
            params[params_c_r] -= params[params_x_c_r] * 0.2 / params[params_scale];
            params[params_c_i] -= params[params_x_c_i] * 0.2 / params[params_scale];
            params[params_z0_r] -= params[params_x_z0_r] * 0.2 / params[params_scale];
            params[params_z0_i] -= params[params_x_z0_i] * 0.2 / params[params_scale];
			break;
		case KEY_UP:
			printf("up\n");
            params[params_c_r] += params[params_y_c_r] * 0.2 / params[params_scale];
            params[params_c_i] += params[params_y_c_i] * 0.2 / params[params_scale];
            params[params_z0_r] += params[params_y_z0_r] * 0.2 / params[params_scale];
            params[params_z0_i] += params[params_y_z0_i] * 0.2 / params[params_scale];
			break;
		case KEY_RIGHT:
			printf("right\n");
            params[params_c_r] += params[params_x_c_r] * 0.2 / params[params_scale];
            params[params_c_i] += params[params_x_c_i] * 0.2 / params[params_scale];
            params[params_z0_r] += params[params_x_z0_r] * 0.2 / params[params_scale];
            params[params_z0_i] += params[params_x_z0_i] * 0.2 / params[params_scale];
			break;
		case KEY_DOWN:
			printf("down\n");
            params[params_c_r] -= params[params_y_c_r] * 0.2 / params[params_scale];
            params[params_c_i] -= params[params_y_c_i] * 0.2 / params[params_scale];
            params[params_z0_r] -= params[params_y_z0_r] * 0.2 / params[params_scale];
            params[params_z0_i] -= params[params_y_z0_i] * 0.2 / params[params_scale];
			break;
		default:
			break;
	}

    update_axis();
	redraw();
}


struct clinfo
{
	cl_device_id device_id;
	cl_context context;
	cl_command_queue command_queue;
	cl_mem img;
	cl_mem params;
	cl_program program;
	cl_kernel kernel;
	cl_platform_id platform_id;
	cl_uint ret_num_devices;
	cl_uint ret_num_platforms;
	cl_uint ret_max_workgroup;
} *clinfo = NULL;

void opencl_init()
{
	cl_int ret;

	FILE *f;
	char *source_str;
	size_t source_size;
	int i, x, y;

    clinfo = calloc(sizeof(struct clinfo), 1);

	/* Load the source code containing the kernel*/
	f = fopen( "kernel.cl", "r");
	if (!f)
	{
		fprintf(stderr, "Failed to load kernel.\n");
		exit(1);
	}

	source_str = malloc(1048576);
	source_size = fread(source_str, 1, 1048576, f);
	fclose(f);

	/* Get Platform and Device Info */
	ret = clGetPlatformIDs(1, &clinfo->platform_id, &clinfo->ret_num_platforms);
	printf("clGetPlatformIDs %i\n",ret); 
	ret = clGetDeviceIDs(clinfo->platform_id, CL_DEVICE_TYPE_DEFAULT, 1, &clinfo->device_id, &clinfo->ret_num_devices);
	printf("clGetDeviceIDs %i\n",ret); 
    ret = clGetDeviceInfo(clinfo->device_id, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(cl_uint), &clinfo->ret_max_workgroup, NULL);
	printf("clGetDeviceInfo %i\n",ret); 
	printf("max workgroup %i\n", clinfo->ret_max_workgroup); 

	/* Create OpenCL context */
	clinfo->context = clCreateContext(NULL, 1, &clinfo->device_id, NULL, NULL, &ret);
	printf("clCreateContext %i\n",ret); 

	/* Create Command Queue */
	clinfo->command_queue = clCreateCommandQueue(clinfo->context, clinfo->device_id, 0, &ret);
	printf("clCreateCommandQueue %i\n",ret); 

	/* Create Memory Buffer */
	clinfo->img = clCreateBuffer(clinfo->context, CL_MEM_WRITE_ONLY, X * Y * sizeof(double), NULL, &ret);
	printf("clCreateBuffer %i\n",ret); 
	clinfo->params = clCreateBuffer(clinfo->context, CL_MEM_READ_ONLY, n_params * sizeof(double), NULL, &ret);
	printf("clCreateBuffer %i\n",ret); 

	/* Create Kernel Program from the source */
	clinfo->program = clCreateProgramWithSource(clinfo->context, 1, (const char **)&source_str, &source_size, &ret);
	printf("clCreateProgramWithSource %i\n",ret); 

	/* Build Kernel Program */
	ret = clBuildProgram(clinfo->program, 1, &clinfo->device_id, NULL, NULL, NULL);
	printf("clBuildProgram %i\n",ret); 
    if (ret == CL_BUILD_PROGRAM_FAILURE) {
        // Determine the size of the log
        size_t log_size;
        clGetProgramBuildInfo(clinfo->program, clinfo->device_id, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);

        // Allocate memory for the log
        char *log = (char *) malloc(log_size);

        // Get the log
        clGetProgramBuildInfo(clinfo->program, clinfo->device_id, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);

        // Print the log
        printf("%s\n", log);
    }

	/* Create OpenCL Kernel */
	clinfo->kernel = clCreateKernel(clinfo->program, "kern", &ret);
	printf("clCreateKernel %i\n",ret); 
}

double *render()
{
	int x, y, i;
	double *img = calloc(X * Y, sizeof(double));
	cl_int ret;

	printf("cl\n");
    clEnqueueWriteBuffer(clinfo->command_queue, clinfo->params, CL_TRUE, 0, n_params * sizeof(double), params, 0, NULL, NULL);

	/* Set OpenCL Kernel Parameters */
	ret = clSetKernelArg(clinfo->kernel, 0, sizeof(cl_mem), &clinfo->img);
	printf("clSetKernelArg %i\n",ret); 
	ret = clSetKernelArg(clinfo->kernel, 1, sizeof(cl_mem), &clinfo->params);
	printf("clSetKernelArg %i\n",ret); 

	/* Execute OpenCL Kernel */
	size_t work_size[] = {clinfo->ret_max_workgroup};
	size_t work_dim[] = {clinfo->ret_max_workgroup};
	ret = clEnqueueNDRangeKernel(clinfo->command_queue,  clinfo->kernel, 1, NULL, (const size_t *) work_dim, 
						(const size_t *) work_size, 0, NULL, NULL);
	printf("clEnqueueNDRangeKernel %i\n",ret); 

	/* Copy results from the memory buffer */
	ret = clEnqueueReadBuffer(clinfo->command_queue, clinfo->img, CL_TRUE, 0, X * Y * sizeof(double), img, 0, NULL, NULL);
	printf("clEnqueueReadBuffer %i\n",ret); 

	normalize(img, X, Y);

	printf("/cl\n");

    return img;
}


void redraw()
{
    int i;
    double *img = render();
	plot(img, NULL);
	free(img);
}

void reshape(int width,int height)
{
	return;
}

int main(int argc, char **argv)
{
    int i;
    for (i = 0; i < n_params; i++)
        params_key[i] = params[i];

    opencl_init();

	glutInit(&argc, argv);
	glutInitWindowSize(X, Y);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
	glutCreateWindow("fooBar");

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	glutDisplayFunc(redraw);
	//glutReshapeFunc(reshape);
	glutKeyboardFunc(key_handler);
	glutSpecialFunc(special_key_handler);

	glutMainLoop();

	return 0;
}
